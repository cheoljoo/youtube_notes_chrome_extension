// Extracts title, description, videoId and tries to fetch transcript via timedtext
(async function(){
  // content script is executed by popup via scripting.executeScript; kept for future use
  // This file can be registered if needed.
})();
